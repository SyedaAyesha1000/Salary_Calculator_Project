import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.lang.Thread;
import java.time.Duration;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Alert;

public class Lab5 {
	public static void waitMethod(long x) {
		try {
			Thread.sleep(x);
		}
		catch(Exception e) {
			System.out.println(e);
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C://Users//user//Downloads//chromedriver_win32/chromedriver.exe");

		//initialize a variable to utilize
		WebDriver driver = new ChromeDriver(); 
		
		//to maximize the opened window
		driver.manage().window().maximize(); 
		
		// to open specific site
		driver.get("https://omayo.blogspot.in/");
		
		Actions action = new Actions(driver);
		/*
		driver.findElement(By.xpath("//div[@class='widget-content']//child::textarea")).sendKeys("Sayyada Ayesha");
		
		action.sendKeys(Keys.PAGE_DOWN).build().perform();
		
		String textArea2 = driver.findElement(By.linkText("The cat was playing in the garden.")).getText();
		System.out.println(textArea2);
		
		//WebElement clearDescription = driver.findElement(By.linkText("The cat was playing in the garden."));
		//clearDescription.clear();
		waitMethod(2000);
		driver.findElement(By.xpath("//div[@id='HTML11']//child::div//child::textarea")).sendKeys("I am punctual student. I used to follow regular routine to make everything on time");
		//System.out.println(description);
		//driver.findElement(By.linkText("The cat was playing in the garden.")).clear();
		waitMethod(1000);
		//clearDescription.sendKeys("I am punctual student. I used to follow regular routine to make everything on time");
		 */
		/*
		String innerText = driver.findElement(By.xpath("//table//thead//th[1]")).getText();
		System.out.print(innerText +"  ");
		
		String innerText1 = driver.findElement(By.xpath("//table//thead//th[2]")).getText();
		System.out.print(innerText1 +"  ");
		
		String innerText2 = driver.findElement(By.xpath("//table//thead//th[3]")).getText();
		System.out.println(innerText2+" ");
		
		String innerText3 = driver.findElement(By.xpath("//table//tbody//tr[1]//td[1]")).getText();
		System.out.print(innerText3+" ");
		
		String innerText4 = driver.findElement(By.xpath("//table//tbody//tr[1]//td[2]")).getText();
		System.out.print(innerText4+" ");
		
		String innerText5 = driver.findElement(By.xpath("//table//tbody//tr[1]//td[3]")).getText();
		System.out.println(innerText5+" ");
		
		String innerText6 = driver.findElement(By.xpath("//table//tbody//tr[2]//td[1]")).getText();
		System.out.print(innerText6+" ");
		
		String innerText7 = driver.findElement(By.xpath("//table//tbody//tr[2]//td[2]")).getText();
		System.out.print(innerText7+" ");
		
		String innerText8 = driver.findElement(By.xpath("//table//tbody//tr[2]//td[3]")).getText();
		System.out.println(innerText8+" ");
		
		String innerText9 = driver.findElement(By.xpath("//table//tbody//tr[3]//td[1]")).getText();
		System.out.print(innerText9+" ");
		
		String innerText10 = driver.findElement(By.xpath("//table//tbody//tr[3]//td[2]")).getText();
		System.out.print(innerText10+" ");
		
		String innerText11 = driver.findElement(By.xpath("//table//tbody//tr[3]//td[3]")).getText();
		System.out.print(innerText11);
		
		waitMethod(1000);
		
		
		action.sendKeys(Keys.PAGE_DOWN).build().perform();
		
		driver.findElement(By.xpath("//form[@name='form1']//child::input[1]")).sendKeys("sayyadaayesha");
		driver.findElement(By.xpath("//form[@name='form1']//child::input[2]")).sendKeys("abc123");
		driver.findElement(By.xpath("//button[@value='LogIn']")).click();
		*/
		//action.sendKeys(Keys.PAGE_DOWN).build().perform();
		//action.sendKeys(Keys.PAGE_DOWN).build().perform();
		
		String windowHandle = driver.getWindowHandle();
		
		/*
		WebElement frame1 = driver.findElement(By.xpath("//iframe[@src='http://book.theautomatedtester.co.uk']//preceding-sibling::iframe"));
		driver.switchTo().frame(frame1);
		driver.switchTo().window(windowHandle);
		
		waitMethod(1000);
		
		WebElement frame2 = driver.findElement(By.xpath("//iframe[@src='http://book.theautomatedtester.co.uk']"));
		driver.switchTo().frame(frame2);
		driver.switchTo().window(windowHandle);
		*/
		/*
		driver.findElement(By.xpath("//input[@name='userid']")).sendKeys("sayyadaayesha");
		driver.findElement(By.xpath("//input[@name='pswrd']")).sendKeys("abc123");
		driver.findElement(By.xpath("//input[@value='Login']")).click();
		//waitMethod(2000);
		
		Alert alert = driver.switchTo().alert();
		alert.accept();
		
			
		driver.findElement(By.xpath("//div[@class='widget-content']//child::select//option[3]")).click();
		//driver.findElement(By.linkText("//option[@value='Hyundaix']")).click();
		driver.findElement(By.xpath("//div[@class='widget-content']//child::select[@class='combobox']//option[4]")).click();
		//driver.findElement(By.linkText("//option[@value='jkl's]")).click();
		
		driver.findElement(By.xpath("//div[@class='widget-content']//child::input[@value='Selenium WebDriver']")).clear();
		driver.findElement(By.xpath("//div[@class='widget-content']//child::input[@value='Selenium WebDriver']")).sendKeys("Hello World");
		
		
		WebElement clearDescription = driver.findElement(By.xpath("//div[@id='HTML11']//child::div//child::textarea"));
		String innerText0 =  clearDescription.getText();
		System.out.println(innerText0);
		
		clearDescription.clear();
		
		clearDescription.sendKeys("I am punctual student. I used to follow regular routine to make everything on time");
		
		
		
		driver.findElement(By.xpath("//div[@class='widget-content']//child::button[@name='samename'][1]")).click();
		driver.findElement(By.xpath("//div[@class='widget-content']//child::button[@name='samename'][2]")).click();
		driver.findElement(By.xpath("//div[@class='widget-content']//child::button[@name='samename'][3]")).click();
		
		
		
		driver.findElement(By.xpath("//input[@value='ClickAfterTextDissappears']")).click();
		Alert alert = driver.switchTo().alert();
		alert.accept();
		*/
		/*
		driver.findElement(By.linkText("Open a popup window")).click();
		driver.switchTo().frame(1);
		driver.switchTo().window(windowHandle);
		String one = driver.findElement(By.id("main")).getText();
		System.out.println(one);
		String one1 = driver.findElement(By.id("sub")).getText();
		System.out.println(one1);
		*/
		
		
	}

}
